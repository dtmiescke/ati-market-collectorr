# ATI Market Collector

Always-on ATI market-data collector for Fly.io.

## Required Fly secrets
Set these directly in Fly.io. Never commit their values to GitHub:
- `ATI_INGEST_URL`
- `ATI_STREAM_INGEST_SECRET`
- `ALPACA_API_KEY`
- `ALPACA_API_SECRET`

This collector supplies market data only. It does not authorize or place live trades.
